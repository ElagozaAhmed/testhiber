/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package globalFanctions;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author Agoza
 */
public class DBConfig {
    private static SessionFactory factory=null;
    private  Session session = null;
    
    
    
    
    public synchronized static SessionFactory getFactory(){
        if(factory == null || factory.isClosed()) {
            setFactory();
        }
            return factory;
                
    }
    
    public static void setFactory(){
        try {
            factory = new Configuration().configure().buildSessionFactory();
            
        } catch (Exception e) {
            System.out.println("Ther Is Error When Creat Session Factory ?!");
            e.printStackTrace();
        }
        
    }
    
    public Session getSession(){
        getFactory();
        session = factory.openSession();
        return session;
    }
    
    public void closeSesssion(){
        try {
            session.close();
        } catch (Exception e) {
            System.out.println("Error when close The Session ?!");
            e.printStackTrace();
        }
    }
}
