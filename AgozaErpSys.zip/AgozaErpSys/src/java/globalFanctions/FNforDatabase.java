/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package globalFanctions;

import org.hibernate.SQLQuery;
import org.hibernate.criterion.Projections;

/**
 *
 * @author Agoza
 */
public class FNforDatabase {
    
    public static int countOpjects(String tableName,String columnName,String Id){
        
        DBConfig database = new DBConfig();
        int count=0;
        try {
             SQLQuery qury = database.getSession().createSQLQuery("select count("+columnName+") from "+tableName+" where "+columnName+" = '"+Id+"';");
          // count = (int)qury.uniqueResult();
         //count = (Integer)qury.list().get(0);
        count = ((Integer)qury.iterate().next()).intValue();
         
        }catch(NullPointerException e2){
            System.out.println("null");
            return 0;
        } catch (Exception e) {
            System.out.println("Error but Not null?!");
            e.printStackTrace();
        }
       return count;
    }
    
    
    public static int countOpj(String tableName){
         DBConfig database = new DBConfig();
        return (int)database.getSession().createCriteria(tableName)
                  .setProjection(Projections.rowCount())
                  .uniqueResult();
    }
    
    
    
    
}
