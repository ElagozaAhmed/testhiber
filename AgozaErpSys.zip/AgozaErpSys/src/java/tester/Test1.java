/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tester;

//import com.mysql.cj.xdevapi.*;
import databaseConfig.Emps;
import globalFanctions.DBConfig;
import globalFanctions.FNforDatabase;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author Agoza
 */
public class Test1 {
    public static void main(String[] args){
        /*
        SessionFactory factory= null;
        Session session = null;
        try {
            factory= new Configuration().configure().buildSessionFactory();
            session = factory.openSession();
            Transaction trns = session.beginTransaction();
            //session.persist(Emps.class);
            Emps user =(Emps)session.get(Emps.class, "E001");
            System.out.println(user.getCname1()+"  "+user.getCname2());
            
            
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally{
            try {
                session.close();
                factory.close();
        
            } catch (Exception e) {
            e.printStackTrace();
            }
            }
    */
         DBConfig config = new DBConfig();
        Emps user = (Emps)config.getSession().get(Emps.class, "E001");
            System.out.println(user.getCname1()+user.getCname2());
            
            System.out.println(FNforDatabase.countOpjects("emps", "cCode", "E001"));
            System.out.println(FNforDatabase.countOpj("emps"));
    }
    
}
