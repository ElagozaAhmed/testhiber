/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import databaseConfig.Emps;
import globalFanctions.DBConfig;
import globalFanctions.FNforDatabase;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.primefaces.PrimeFaces;

@ManagedBean(name="LogIn")
@SessionScoped
public class LogInBean {

    /**
     * @return the userNameEn
     */
    public String getUserNameEn() {
        return userNameEn;
    }

    /**
     * @param userNameEn the userNameEn to set
     */
    public void setUserNameEn(String userNameEn) {
        this.userNameEn = userNameEn;
    }

    /**
     * @return the userCode
     */
    public String getUserCode() {
        return userCode;
    }

    /**
     * @param userCode the userCode to set
     */
    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    /**
     * @return the userNameAr
     */
    public String getUserNameAr() {
        return userNameAr;
    }

    /**
     * @param userNameAr the userNameAr to set
     */
    public void setUserNameAr(String userNameAr) {
        this.userNameAr = userNameAr;
    }

    /**
     * @return the Password
     */
    public String getPassword() {
        return Password;
    }

    /**
     * @param Password the Password to set
     */
    public void setPassword(String Password) {
        this.Password = Password;
    }

    /**
     * @return the user
     */
    public Emps getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(Emps user) {
        this.user = user;
    }

    /**
     * @return the lang
     */
    public String getLang() {
        return lang;
    }

    /**
     * @param lang the lang to set
     */
    public void setLang(String lang) {
        this.lang = lang;
    }

    /**
     * @return the Company
     */
    public String getCompany() {
        return Company;
    }

    /**
     * @param Company the Company to set
     */
    public void setCompany(String Company) {
        this.Company = Company;
    }
    //-----------------------------------------------------------------------------------
    
    public String checkLogin(){
        
          FacesMessage message = null;
        boolean loggedIn = false;
        //HttpSession session = HttpServletRequest.getSession(false);
        // if(FNforDatabase.countOpjects("Emps", "cCode", userCode) > 0 ){ setUser();} else {System.out.println("No user is thre is");}
        if(userCode != null  && Password != null && Password.equals(user.getCpassWord())) {//&& FNforDatabase.countOpjects("Emps", "cCode", userCode)>0
            loggedIn = true;
            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Welcome", userNameAr);
            System.out.println("user Pass Is : "+user.getCpassWord());
            System.out.println("Enter Pass Is : "+getPassword());
           FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("user", user);
            return "faces/MainForm.xhtml?faces-redirect=true";
        } else {
            loggedIn = false;
            System.out.println("user False Pass Is : "+user.getCpassWord());
            System.out.println("Enter False Pass Is : "+getPassword());
            
            message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Loggin Error", "Invalid credentials");
        }
         
        FacesContext.getCurrentInstance().addMessage(null, message);
        PrimeFaces.current().ajax().addCallbackParam("loggedIn", loggedIn);
        
        
        
        return null;
        
    }
    
    public void setUser (){
        DBConfig config = new DBConfig();
          //  if (this.userCode == null )return;
            this.user = (Emps)config.getSession().get(Emps.class, userCode);
            setUserNameAr(user.getCname1());
            setUserNameEn(user.getCname2());
            //setPassword(user.getCpassWord());    لكى لتوضع فى المكان
            
        config.closeSesssion();
        
    }
    
    //-----------------------------------------------------------------------------------
    
    private String userCode =null;
    private String userNameAr=null;
     private String userNameEn=null;
    private String Password=null;
    private Emps user =null;
    private String lang = "EN";
    private String Company =null;

//private String Permations = "000000000000000000";
    
}
