package Filters;

import databaseConfig.Emps;
import general.GeneralFunStatic;
import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet Filter implementation class LogInFilter
 */
@WebFilter(filterName="/LogInFilter",urlPatterns="*.xhtml")

public class LogInFilter implements Filter {

    /**
     * Default constructor. 
     */
    public LogInFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
	
		//chain.doFilter(request, response);

		System.out.println("in the sesstion filter");
		
		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		String servletPath = httpServletRequest.getServletPath();
		StringBuffer requestURL = httpServletRequest.getRequestURL();
		String requestURI = httpServletRequest.getRequestURI();
		
		System.out.println("servletPath: " + servletPath);
		System.out.println("requestURL: " + requestURL);
		System.out.println("requestURI: " + requestURI);
		HttpSession session = httpServletRequest.getSession(false);
		if((!servletPath.contains("index.xhtml") || !servletPath.contains("LogIn.xhtml")) && session != null) {
                    	String chekEmp = null;
                        Emps emp = null;
                       
			if(session.getAttribute("user") == null ){
                            chekEmp = null;
				System.out.println("Emp = Null");
                                request.getRequestDispatcher("faces/index.xhtml").forward(request, response);
                        }else {
                            emp=(Emps)session.getAttribute("user");
				chekEmp = emp.getCcode();
				System.out.println("Emp = "+emp.getCcode());
			}
			
                        
			if (session == null || GeneralFunStatic.isEmpty(chekEmp) ) { // StaticMethods.isEmpity(emp.getCode())
				//((HttpServletResponse)response).sendRedirect(httpServletRequest.getContextPath() +"/LogIn.xhtml");//httpServletRequest.getContextPath() + 
				request.getRequestDispatcher("index.xhtml").forward(request, response);
				System.out.println("Null Session not exist");
			}else {
				System.out.println("Has Session Next");
				chain.doFilter(request, response);
				//request.getRequestDispatcher("LogIn.xhtml").forward(request, response);
				//httpServletRequest.getRequestDispatcher("LogIn.xhtml").forward(request, response);
			}
		}else {
			chain.doFilter(request, response);
			
		}
		
		//request.getRequestDispatcher("logIn.xhtml").forward(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
