/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package general;

/**
 *
 * @author Agoza
 */
public class GeneralFunStatic {

    public static Object ifEmpty(Object obj) {
        try {
            if (obj == null || obj.toString().trim().equals("")) {

                return "";
            }
            return obj;
        } catch (Exception e) {
            return "";
        }

    }

    
    public static String ifEmpty(String str){
        try {
            if(str == null || str.trim().equals("")){
            return "";
        }
        return str;
        } catch (Exception e) {
            return "";
        }
        
    }
    
    public static boolean isEmpty(Object obj) {
        try {
            if (obj == null || obj.toString().trim().equals("") || obj.hashCode() == 0) {
                return true;
            }
            return false;
        } catch (Exception e) {
            return true;
        }

    }
    
    public static boolean isEmpty(String str) {
        try {
            if (str == null || str.trim().equals("") || str.hashCode() == 0) {
                return true;
            }
            return false;
        } catch (Exception e) {
            return true;
        }

    }


}
